# SloppyGrad 🤪 : Because Perfection is Overrated

Welcome to the wild and wacky world of SloppyGrad, my attempt to learn neural networks but with sprinkles of chaos, a pinch of instability, and lots of crashes.

## What is SloppyGrad?

SloppyGrad is inspired by micrograd and tinygrad it's and autograd engine here to prove that not all software needs to be perfect and well-behaved. my goal is to contribute to tinygrad i believe the best way to learn something is to attempt to recreate it so here we go.

## Getting Started

(Insert installation instructions here)

## TODO:
 - write setup.py with requireed dependencies

