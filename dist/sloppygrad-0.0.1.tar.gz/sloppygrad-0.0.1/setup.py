from setuptools import setup


setup(
        name="sloppygrad",
        version="0.0.1",
        description="sloppygrad a sloppy,cheap version of micorgrad an autograd engine",
        author="abdullah mosaibah",
        author_email="abdullah.rm.2020@gmail.com",
        install_requires=[
            "numpy"
            ]
        )
